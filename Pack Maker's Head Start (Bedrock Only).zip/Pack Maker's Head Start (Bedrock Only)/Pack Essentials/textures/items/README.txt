To change the texture of a Netherite 
Sword for example, make your custom
texture. Then, place in it here and rename
it to "netherite_sword". You can do this with
a diamond axe as well with"diamond_axe".