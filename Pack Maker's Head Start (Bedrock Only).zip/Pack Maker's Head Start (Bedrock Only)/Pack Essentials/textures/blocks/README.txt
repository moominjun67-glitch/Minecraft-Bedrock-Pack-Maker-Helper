To change the texture of a coal ore for
example, make your custom texture.
Then, place it in here and rename it to
"coal_ore". You can do this with copper 
ore as well with "copper_ore".